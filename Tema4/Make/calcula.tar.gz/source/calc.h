#ifndef MYCALC
#define MYCALC

int suma(int op1, int op2);
int resta(int op1, int op2);
int multiplicacio(int op1, int op2);
int divisio(int op1, int op2);
int mayor(int op1, int op2);

#endif
